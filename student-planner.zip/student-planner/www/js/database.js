const DB={k:'sp_db',d:null,
load(){let s=null;try{s=JSON.parse(localStorage.getItem(this.k))}catch(e){}
this.d=Object.assign({matieres:[],devoirs:[],edt:[],revisions:[],profil:{},activites:[],theme:'light'},s&&typeof s==='object'?s:{})},
save(){try{localStorage.setItem(this.k,JSON.stringify(this.d))}catch(e){alert('Stockage plein : exportez vos données.')}},
uid:()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6),
log(t){this.d.activites.unshift({t,d:new Date().toISOString()});this.d.activites=this.d.activites.slice(0,8)},
export(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(this.d,null,1)],{type:'application/json'}));a.download='student-planner-sauvegarde.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500)},
async import(f){const j=JSON.parse(await f.text());
for(const k of['matieres','devoirs','edt','revisions'])if(!Array.isArray(j[k]))throw Error('Fichier invalide');
this.d=Object.assign({profil:{},activites:[],theme:'light'},j);this.save()}};
