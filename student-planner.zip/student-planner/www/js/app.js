(()=>{DB.load();
const $=s=>document.querySelector(s),dlg=$('#dlg'),d=()=>DB.d;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const J=['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi','Dimanche'];
const M=id=>d().matieres.find(m=>m.id===id),today=()=>new Date().toLocaleDateString('sv');
const fmt=s=>s?new Date(s+'T00:00').toLocaleDateString('fr-FR',{day:'numeric',month:'short',year:'numeric'}):'';
const dot=id=>`<span class="dot" style="background:${esc(M(id)?.couleur||'#888')}"></span>`;
const SC={matieres:{t:'Matière',f:[['nom','text','Nom',1],['desc','textarea','Description'],['couleur','color','Couleur']]},
devoirs:{t:'Devoir',f:[['titre','text','Titre',1],['desc','textarea','Description'],['matiere','mat','Matière',1],['type','sel','Type',1,['Devoir','TD','Examen']],['date','date','Date limite',1],['priorite','sel','Priorité',1,['Haute','Moyenne','Basse']]]},
edt:{t:'Cours',f:[['jour','sel','Jour',1,J],['matiere','mat','Matière',1],['debut','time','Début',1],['fin','time','Fin',1],['salle','text','Salle']]},
revisions:{t:'Révision',f:[['matiere','mat','Matière',1],['date','date','Date',1],['duree','number','Durée (min)',1]]}};
let tm;const toast=m=>{const t=$('#toast');t.textContent=m;t.className='on';clearTimeout(tm);tm=setTimeout(()=>t.className='',2500)};
const acts=(c,id)=>`<button class="ic" data-act="edit" data-c="${c}" data-id="${id}" aria-label="Modifier">✎</button><button class="ic" data-act="del" data-c="${c}" data-id="${id}" aria-label="Supprimer">✕</button>`;
const add=(c,l)=>`<div class="tool"><span class="m">${d()[c].length} élément(s)</span><button class="btn" data-act="add" data-c="${c}">+ ${l}</button></div>`;
const empty=t=>`<div class="card m">${t}</div>`;
function field([k,ty,l,req,o],v){v=v??'';let i;
if(ty=='textarea')i=`<textarea name="${k}" maxlength="300">${esc(v)}</textarea>`;
else if(ty=='sel'||ty=='mat'){const L=ty=='mat'?d().matieres.map(m=>[m.id,m.nom]):o.map(x=>[x,x]);i=`<select name="${k}">${L.map(([a,b])=>`<option value="${esc(a)}"${a==v?' selected':''}>${esc(b)}</option>`).join('')}</select>`}
else i=`<input name="${k}" type="${ty}" value="${esc(v||(ty=='color'?'#2f6fd0':''))}" ${req?'required':''} ${ty=='text'?'maxlength="60"':''} ${ty=='number'?'min="5" max="600"':''}>`;
return `<label>${l}${req?' *':''}${i}</label>`}
function form(c,id){if(c!='matieres'&&!d().matieres.length)return toast("Ajoutez d'abord une matière");
const it=id?d()[c].find(x=>x.id===id):{};
dlg.innerHTML=`<form id="f"><h2>${id?'Modifier':'Ajouter'} · ${SC[c].t}</h2>${SC[c].f.map(f=>field(f,it[f[0]])).join('')}<div class="row"><button type="button" class="btn ghost" data-act="close">Annuler</button><button class="btn">Enregistrer</button></div></form>`;
dlg.showModal();
$('#f').onsubmit=e=>{e.preventDefault();const fd=new FormData(e.target),o={};
for(const f of SC[c].f){const v=String(fd.get(f[0])||'').trim();if(f[3]&&!v)return toast('Champ requis : '+f[2]);
if(f[1]=='mat'&&!M(v))return toast('Matière invalide');if(f[1]=='sel'&&!f[4].includes(v))return toast('Valeur invalide');o[f[0]]=v}
if(c=='matieres'&&!/^#[0-9a-f]{6}$/i.test(o.couleur))o.couleur='#2f6fd0';
if(c=='edt'&&o.fin<=o.debut)return toast("L'heure de fin doit suivre le début");
if(c=='revisions')o.duree=Math.min(600,Math.max(5,+o.duree||30));
if(id)Object.assign(it,o);else d()[c].push({id:DB.uid(),fait:false,...o});
DB.log((id?'Modifié : ':'Ajouté : ')+(o.nom||o.titre||SC[c].t));DB.save();dlg.close();render()}}
const dv=x=>`<div class="it${x.fait?' done':''}${!x.fait&&x.date<today()?' late':''}"><button class="ck" data-act="tog" data-c="devoirs" data-id="${x.id}" aria-label="Terminé">${x.fait?'✓':''}</button><div class="g"><b>${esc(x.titre)}</b><small>${dot(x.matiere)}${esc(M(x.matiere)?.nom||'—')} · ${esc(x.type)} · ${fmt(x.date)} · <i class="p-${esc(x.priorite)}">${esc(x.priorite)}</i></small>${x.desc?`<p>${esc(x.desc)}</p>`:''}</div>${acts('devoirs',x.id)}</div>`;
const byDate=(a,b)=>a.date.localeCompare(b.date);
let cal={y:new Date().getFullYear(),m:new Date().getMonth(),s:today()};
const V={
dashboard(){const D=d(),n=D.devoirs.length,ok=D.devoirs.filter(x=>x.fait).length,p=n?Math.round(ok/n*100):0,nx=D.devoirs.filter(x=>!x.fait).sort(byDate).slice(0,5);
return `<div class="card"><h2>Bonjour${D.profil.prenom?', '+esc(D.profil.prenom):''} 👋</h2><p class="m">Voici l'état de vos études aujourd'hui.</p></div>
<div class="grid"><div class="card"><b>${D.matieres.length}</b>Matières</div><div class="card"><b>${n}</b>Devoirs</div><div class="card"><b>${ok}</b>Terminés</div><div class="card"><b>${n-ok}</b>Restants</div></div>
<div class="card" style="margin-top:12px"><div class="tool"><b>Progression générale</b><b>${p}%</b></div><div class="bar"><i style="width:${p}%"></i></div></div>
<h3 style="margin:14px 0 8px">Prochains devoirs</h3>${nx.map(dv).join('')||empty('Aucun devoir à rendre.')}
<h3 style="margin:14px 0 8px">Activités récentes</h3>${D.activites.map(a=>`<div class="it"><div class="g">${esc(a.t)}<small>${new Date(a.d).toLocaleString('fr-FR')}</small></div></div>`).join('')||empty('Aucune activité.')}`},
matieres(){return add('matieres','Matière')+(d().matieres.map(m=>`<div class="it" style="border-left:6px solid ${esc(m.couleur)}"><div class="g"><b>${esc(m.nom)}</b>${m.desc?`<small>${esc(m.desc)}</small>`:''}</div>${acts('matieres',m.id)}</div>`).join('')||empty('Aucune matière. Commencez par en ajouter une.'))},
devoirs(){return add('devoirs','Devoir')+([...d().devoirs].sort(byDate).map(dv).join('')||empty('Aucun devoir.'))},
edt(){return add('edt','Cours')+J.map(j=>{const L=d().edt.filter(x=>x.jour==j).sort((a,b)=>a.debut.localeCompare(b.debut));
return `<section class="card"><h3>${j}</h3>${L.map(x=>`<div class="it" style="box-shadow:none;margin:8px 0 0"><div class="g"><b>${esc(x.debut)} – ${esc(x.fin)}</b> ${dot(x.matiere)}${esc(M(x.matiere)?.nom||'—')}<small>Salle : ${esc(x.salle||'—')}</small></div>${acts('edt',x.id)}</div>`).join('')||'<p class="m">Libre</p>'}</section>`}).join('')},
revisions(){const R=d().revisions,mn=R.filter(x=>x.fait).reduce((s,x)=>s+x.duree,0);
return add('revisions','Révision')+`<div class="card">Effectuées : <b>${R.filter(x=>x.fait).length}/${R.length}</b> séances · <b>${mn}</b> min</div>`+([...R].sort(byDate).map(x=>`<div class="it${x.fait?' done':''}"><button class="ck" data-act="tog" data-c="revisions" data-id="${x.id}" aria-label="Effectuée">${x.fait?'✓':''}</button><div class="g"><b>${dot(x.matiere)}${esc(M(x.matiere)?.nom||'—')}</b><small>${fmt(x.date)} · ${x.duree} min</small></div>${acts('revisions',x.id)}</div>`).join('')||empty('Aucune séance planifiée.'))},
calendrier(){const ev=[...d().devoirs.map(x=>({date:x.date,l:`${x.type} : ${x.titre}`,c:M(x.matiere)?.couleur})),...d().revisions.map(x=>({date:x.date,l:'Révision : '+(M(x.matiere)?.nom||''),c:M(x.matiere)?.couleur}))];
const off=(new Date(cal.y,cal.m,1).getDay()+6)%7,nd=new Date(cal.y,cal.m+1,0).getDate(),p=n=>String(n).padStart(2,'0');let cells='';
for(let i=0;i<off;i++)cells+='<i></i>';
for(let n=1;n<=nd;n++){const s=`${cal.y}-${p(cal.m+1)}-${p(n)}`,E=ev.filter(e=>e.date==s);cells+=`<button class="${s==cal.s?'sel ':''}${s==today()?'td':''}" data-act="day" data-d="${s}">${n}<br>${E.slice(0,3).map(e=>`<span class="dot" style="background:${esc(e.c||'#888')}"></span>`).join('')}</button>`}
const sel=ev.filter(e=>e.date==cal.s);
return `<div class="card"><div class="tool"><button class="ic" data-act="mon" data-n="-1" aria-label="Mois précédent">◀</button><b>${new Date(cal.y,cal.m,1).toLocaleDateString('fr-FR',{month:'long',year:'numeric'})}</b><button class="ic" data-act="mon" data-n="1" aria-label="Mois suivant">▶</button></div>
<div class="cal">${['L','M','M','J','V','S','D'].map(x=>`<span>${x}</span>`).join('')}${cells}</div></div>
<div class="card"><b>${fmt(cal.s)}</b>${sel.map(e=>`<div>${dot('')}${esc(e.l)}</div>`).join('')||'<p class="m">Rien de prévu.</p>'}</div>`},
profil(){const p=d().profil;
return `<form class="card" id="pf"><img class="avatar" id="av" alt="Photo de profil" ${p.photo?`src="${esc(p.photo)}"`:''}>
<label>Photo (facultative)<input type="file" id="photo" accept="image/*"></label>
${[['nom','Nom'],['prenom','Prénom'],['formation','Formation'],['universite','Université'],['niveau','Niveau d\'études']].map(([k,l])=>`<label>${l}<input name="${k}" maxlength="60" value="${esc(p[k])}"></label>`).join('')}
<div class="row"><button class="btn">Enregistrer le profil</button></div></form>
<div class="card"><h3>Données et préférences</h3><p class="m" style="margin-bottom:10px">Tout est stocké uniquement sur cet appareil.</p>
<div class="row" style="justify-content:flex-start"><button class="btn" data-act="theme">Thème clair/sombre</button><button class="btn" data-act="export">Exporter</button><button class="btn ghost" data-act="import">Restaurer</button><button class="btn red" data-act="reset">Tout effacer</button></div>
<input type="file" id="imp" accept="application/json" hidden></div>`}};
const T={dashboard:'Tableau de bord',matieres:'Matières',devoirs:'Devoirs & TD',edt:'Emploi du temps',revisions:'Révisions',calendrier:'Calendrier',profil:'Mon profil'};
function render(){const v=V[location.hash.slice(2)]?location.hash.slice(2):'dashboard';
document.documentElement.dataset.theme=d().theme;$('#ttl').textContent=T[v];
document.querySelectorAll('#nav a').forEach(a=>a.classList.toggle('on',a.dataset.v==v));$('#view').innerHTML=V[v]()}
document.addEventListener('click',e=>{const b=e.target.closest('[data-act]');if(!b)return;const{act,c,id}=b.dataset;
if(act=='add')form(c);else if(act=='edit')form(c,id);else if(act=='close')dlg.close();
else if(act=='del'){if(!confirm('Supprimer cet élément ?'))return;
if(c=='matieres')['devoirs','edt','revisions'].forEach(k=>d()[k]=d()[k].filter(x=>x.matiere!=id));
d()[c]=d()[c].filter(x=>x.id!=id);DB.log('Supprimé : '+SC[c].t);DB.save();render()}
else if(act=='tog'){const x=d()[c].find(x=>x.id==id);x.fait=!x.fait;if(x.fait)DB.log('Terminé : '+(x.titre||'séance de révision'));DB.save();render()}
else if(act=='day'){cal.s=b.dataset.d;render()}
else if(act=='mon'){cal.m+=+b.dataset.n;if(cal.m<0){cal.m=11;cal.y--}if(cal.m>11){cal.m=0;cal.y++}render()}
else if(act=='theme'){d().theme=d().theme=='dark'?'light':'dark';DB.save();render()}
else if(act=='export')DB.export();else if(act=='import')$('#imp').click();
else if(act=='reset'&&confirm('Effacer TOUTES les données ?')){localStorage.removeItem(DB.k);DB.load();render()}});
document.addEventListener('submit',e=>{if(e.target.id!='pf')return;e.preventDefault();const fd=new FormData(e.target);
['nom','prenom','formation','universite','niveau'].forEach(k=>d().profil[k]=String(fd.get(k)||'').trim().slice(0,60));DB.log('Profil mis à jour');DB.save();toast('Profil enregistré');render()});
document.addEventListener('change',async e=>{const f=e.target.files&&e.target.files[0];if(!f)return;
if(e.target.id=='photo'){if(!f.type.startsWith('image/'))return toast('Image requise');const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=c.height=200;const x=c.getContext('2d'),s=Math.min(im.width,im.height);x.drawImage(im,(im.width-s)/2,(im.height-s)/2,s,s,0,0,200,200);d().profil.photo=c.toDataURL('image/jpeg',.8);DB.save();render()};im.src=URL.createObjectURL(f)}
if(e.target.id=='imp'){try{if(!confirm('Remplacer les données actuelles ?'))return;await DB.import(f);render();toast('Données restaurées')}catch(x){toast('Fichier invalide')}}});
addEventListener('hashchange',render);render();
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
})();
